<template>
    <!-- contact us section  -->
    <section class="main-page-padding">
        <section class="contact-section">
            <div class="contact-container">
                <!-- Left Content -->
                <div class="contact-info">
                    <p class="contact-subtitle">CONTACT US</p>
                    <h2 class="contact-title">
                        Feel Free To Contact Us Anytime
                    </h2>
                    <p class="contact-description">
                        We’re here to help! Whether you have a question, need
                        support, or simply want to share your feedback, our team
                        is always ready to assist you. You can reach us through
                        phone, email, or by filling out the contact form on this
                        page. We aim to respond to all inquiries as quickly as
                        possible and ensure you get the support you need. Your
                        satisfaction is our priority, and we look forward to
                        hearing from you!
                    </p>
                    <div class="contact-offer">
                        <div class="offer-circle">
                            <span class="offer-text"
                                >OFF<br /><strong>50%</strong></span
                            >
                        </div>
                        <div class="offer-details">
                            <p>
                                <small
                                    >VALID: <strong>24 SEP 2025</strong></small
                                >
                            </p>
                            <p>
                                <strong
                                    >Special Offer
                                    <span class="highlight">50%</span>
                                    OFF!</strong
                                >
                            </p>
                        </div>
                        <button class="offer-btn">→</button>
                    </div>
                </div>

                <!-- Right Form -->
                <div class="contact-form">
                    <img
                        class="contact-form-img-1"
                        src="../../front/img/contact-img-1.png"
                        alt=""
                    />
                    <img
                        class="contact-form-img-2"
                        src="../../front/img/contact-img-2.png"
                        alt=""
                    />
                    <form id="contactForm">
                        <input
                            type="text"
                            placeholder="Your Name..."
                            required
                        />
                        <input
                            type="email"
                            placeholder="Your E-mail..."
                            required
                        />
                        <textarea
                            placeholder="Your Message"
                            required
                        ></textarea>
                        <button type="submit">Send Message Now</button>
                    </form>
                </div>
            </div>
        </section>
    </section>

    <!-- footer section  -->

    <section class="footer-section">
        <p>Copyright © 2025 RNTU University. All rights reserved.</p>
        <img src="../../front/img/footer-img.png" class="footer-img" alt="" />
    </section>
</template>

<script setup></script>
