<script setup>
import Header from '../components/Header.vue'
import Footer from '../components/Footer.vue'
import Home from '../components/Home.vue'
</script>

<template>
  <div>
    <Header />
    <Home />
    <Footer />
  </div>
</template>
